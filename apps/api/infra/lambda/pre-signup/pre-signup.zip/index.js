var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// index.ts
var pre_signup_exports = {};
__export(pre_signup_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(pre_signup_exports);
var import_client_cognito_identity_provider = require("@aws-sdk/client-cognito-identity-provider");
var cognito = new import_client_cognito_identity_provider.CognitoIdentityProviderClient({});
var handler = async (event) => {
  const startTime = Date.now();
  const { triggerSource, userPoolId, userName, request } = event;
  const email = request.userAttributes.email;
  console.log(
    JSON.stringify({
      level: "INFO",
      action: "pre_signup_triggered",
      triggerSource,
      userName,
      email
    })
  );
  if (triggerSource === "PreSignUp_SignUp") {
    const federatedUser = await findFederatedUserByEmail(userPoolId, email);
    if (federatedUser) {
      console.log(
        JSON.stringify({
          level: "INFO",
          action: "native_signup_blocked_duplicate_email",
          email,
          existingFederatedUser: federatedUser
        })
      );
      throw new Error(
        "An account with this email already exists. Please sign in with Google instead."
      );
    }
    return event;
  }
  if (triggerSource !== "PreSignUp_ExternalProvider") {
    return event;
  }
  if (request.userAttributes.email_verified !== "true") {
    console.warn(
      JSON.stringify({
        level: "WARN",
        action: "unverified_email_blocked",
        email,
        userName
      })
    );
    return event;
  }
  const [providerName, providerSub] = parseProviderFromUsername(userName);
  if (!providerName || !providerSub) {
    console.error(`Cannot parse provider from userName: ${userName}`);
    return event;
  }
  const nativeUsername = await findNativeUserByEmail(userPoolId, email);
  let linked = false;
  if (nativeUsername) {
    console.log(
      JSON.stringify({
        level: "INFO",
        action: "linking_accounts",
        email,
        nativeUsername,
        federatedProvider: providerName,
        federatedSub: providerSub
      })
    );
    try {
      await cognito.send(
        new import_client_cognito_identity_provider.AdminLinkProviderForUserCommand({
          UserPoolId: userPoolId,
          DestinationUser: {
            ProviderName: "Cognito",
            ProviderAttributeValue: nativeUsername
            // native user's USERNAME
          },
          SourceUser: {
            ProviderName: providerName,
            // "Google"
            ProviderAttributeName: "Cognito_Subject",
            ProviderAttributeValue: providerSub
            // Google's sub ID
          }
        })
      );
      linked = true;
    } catch (error) {
      if (error.name === "InvalidParameterException" && error.message?.includes("already exists")) {
        console.log("Identity already linked, skipping");
        linked = true;
      } else {
        console.error(
          JSON.stringify({
            level: "ERROR",
            action: "link_failed",
            email,
            error: error.message
          })
        );
      }
    }
  }
  event.response.autoConfirmUser = true;
  event.response.autoVerifyEmail = true;
  console.log(
    JSON.stringify({
      level: "INFO",
      action: "pre_signup_complete",
      email,
      linked,
      duration_ms: Date.now() - startTime
    })
  );
  return event;
};
function parseProviderFromUsername(userName) {
  const idx = userName.indexOf("_");
  if (idx === -1) return [null, null];
  return [userName.substring(0, idx), userName.substring(idx + 1)];
}
async function findNativeUserByEmail(userPoolId, email) {
  const result = await cognito.send(
    new import_client_cognito_identity_provider.ListUsersCommand({
      UserPoolId: userPoolId,
      Filter: `email = "${email}"`,
      Limit: 10
    })
  );
  if (!result.Users || result.Users.length === 0) return null;
  const nativeUser = result.Users.find((user) => {
    const username = user.Username ?? "";
    return !username.includes("_") || isUUID(username);
  });
  return nativeUser?.Username ?? null;
}
function isUUID(str) {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(
    str
  );
}
async function findFederatedUserByEmail(userPoolId, email) {
  const result = await cognito.send(
    new import_client_cognito_identity_provider.ListUsersCommand({
      UserPoolId: userPoolId,
      Filter: `email = "${email}"`,
      Limit: 10
    })
  );
  if (!result.Users || result.Users.length === 0) return null;
  const federatedUser = result.Users.find((user) => {
    const username = user.Username ?? "";
    return username.includes("_") && !isUUID(username);
  });
  return federatedUser?.Username ?? null;
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
